from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome("C:/Selenium/chromedriver.exe")
driver.get("https://demoqa.com/upload-download")
localFile_path = "C:\\Selenium\\test.txt"


upload_button_locator = (By.ID, 'uploadFile')
upload_button = driver.find_element(*upload_button_locator)
upload_button.send_keys('C:\\Selenium\\test.txt')

upload_file_path_locator = (By.ID, 'uploadedFilePath')
upload_file_path = driver.find_element(*upload_file_path_locator)

nameFile = localFile_path.rsplit('\\', maxsplit=1)[1]
nameUploadedFile= upload_file_path.text.rsplit('\\', maxsplit=1)[1]

print(nameUploadedFile)
assert nameFile == nameUploadedFile, 'Имя не совпадает'