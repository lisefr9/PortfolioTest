from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome("C:/Selenium/chromedriver.exe")
driver.get("https://demoqa.com/alerts")

alert_button_locator = (By.ID, 'alertButton')
alert_button = driver.find_element(*alert_button_locator)
alert_button.click()

alert = driver.switch_to.alert
alert_text = alert.text

print('alert = ', alert_text)
assert alert_text == 'You clicked a button'
alert.accept()

after_5_button_locator =(By.ID, 'timerAlertButton')
after_5_button = driver.find_element(*after_5_button_locator)
after_5_button.click()
alert = WebDriverWait(driver, 5).until(EC.alert_is_present())
alert_text = alert.text
print('alert2 = ', alert_text)

