from selenium import webdriver
from selenium.webdriver.common.by import By
driver = webdriver.Chrome("C:/Selenium/chromedriver.exe")
driver.get("https://demoqa.com/webtables")
search_text = 'Cierra'

delete_button_locator = (By.ID, 'delete-record-1')
delete_button = driver.find_element(*delete_button_locator)
delete_button.click()

search_box_locator = (By.ID, 'searchBox')
search_box = driver.find_element(*search_box_locator)
search_box.send_keys(search_text)

message_box = driver.find_element_by_class_name('rt-noData')
assert message_box.text == 'No rows found', 'the user has not been deleted'




