from collections import namedtuple
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
driver = webdriver.Chrome("C:/Selenium/chromedriver.exe")
driver.get("https://demoqa.com/webtables")

ElementValue = namedtuple('ElementValue', ['id', 'value'])
element_values = [ElementValue(*el) for el in [
    ['firstName', 'Alex'],
    ['lastName', 'Smirnov'],
    ['userEmail', 'userEmail@mail.ru'],
    ['age', '25'],
    ['salary', '10000'],
    ['department', 'Legal']
]]

# for ev in element_values:
#     print(f'{ev.id}\t{ev.value}')
add_button_locator = (By.ID, 'addNewRecordButton')
add_button = driver.find_element(*add_button_locator)
add_button.click()

for ev in element_values:
    element_locator = (By.ID, ev.id)
    driver.find_element(*element_locator).send_keys(ev.value)

submit_button_locator = (By.ID, 'submit')
submit_button = driver.find_element(*submit_button_locator)
submit_button.click()

search_box_locator = (By.ID, 'searchBox')
search_box = driver.find_element(*search_box_locator)

for el in element_values:
    search_box.send_keys(el.value)
    try:
        WebDriverWait(driver, 5).until(
            lambda driver: driver.execute_script("return false"))
    except TimeoutException:
        search_box.clear()