from selenium import webdriver
from selenium.webdriver.common.by import By
from collections import namedtuple
driver = webdriver.Chrome("C:/Selenium/chromedriver.exe")
driver.get("https://demoqa.com/webtables")

ElementValue = namedtuple('ElementValue', ['id', 'value'])
element_values = [ElementValue(*el) for el in [
    ['firstName', 'Alex'],
    ['lastName', 'Smirnov'],
    ['userEmail', 'userEmail@mail.ru'],
    ['age', '25'],
    ['salary', '10000'],
    ['department', 'Legal']
]]

# for ev in element_values:
#     print(f'{ev.id}\t{ev.value}')

edit_button_locator = (By.ID, 'edit-record-1')
edit_button = driver.find_element(*edit_button_locator)
edit_button.click()

for ev in element_values:
    element_locator = (By.ID, ev.id)
    driver.find_element(*element_locator).clear()
    driver.find_element(*element_locator).send_keys(ev.value)

submit_button_locator = (By.ID, 'submit')
submit_button = driver.find_element(*submit_button_locator)
submit_button.click()

