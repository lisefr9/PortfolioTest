from selenium import webdriver
from selenium.webdriver.common.by import By
driver = webdriver.Chrome("C:/Selenium/chromedriver.exe")
driver.get("https://demoqa.com/webtables")
search_text = 'Cierra'
search_box_locator = (By.ID, 'searchBox')
search_box = driver.find_element(*search_box_locator)
search_box.send_keys(search_text)

row_box = driver.find_element_by_class_name('rt-td')
print('row_box = ', row_box.text)
assert row_box.text == search_text, 'username not founded'

search_box.clear()
search_box.send_keys(search_text + 'a')

message_box = driver.find_element_by_class_name('rt-noData')
print('message_box = ', message_box.text)
assert message_box.text == 'No rows found', 'нет сообщения об отсутствии результата поиска'