from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver import ActionChains

def waiting_for_element(element_id, timeout, wait_type):
  try:
    if wait_type == 'enabled':
      button = WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((By.ID, element_id)))
    elif wait_type == 'visible':
      button = WebDriverWait(driver, timeout).until(EC.visibility_of_element_located((By.ID, element_id)))
    else:
      print('Unsupported wait type')
      return
  except TimeoutException:
    print('Timeout exceeded')
  except BaseException as err:
    print(f"Unexpected {err=}, {type(err)=}")
  else:
    print(f"Wait is over, going to click the {element_id} button")
    return button

driver = webdriver.Chrome("C:/Selenium/chromedriver.exe")
driver.get("https://demoqa.com/dynamic-properties")
actions = ActionChains(driver)

button_a = waiting_for_element('enableAfter', 5, 'enabled')
if not button_a is None:
  actions.click(button_a)

button_b = waiting_for_element('visibleAfter', 5, 'visible')
if not button_b is None:
  actions.click(button_b)

actions.perform()

# driver.quit()
