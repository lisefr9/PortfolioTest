from selenium import webdriver
from selenium.webdriver.common.by import By
driver = webdriver.Chrome("C:/Selenium/chromedriver.exe")
driver.get("https://demoqa.com/browser-windows")

print(driver.current_window_handle)

windows_handle = driver.current_window_handle

parent_handle = driver.window_handles[0]

new_tub_button_locator = (By.ID, 'tabButton')
new_tub_button = driver.find_element(*new_tub_button_locator)
new_tub_button.click()

child_handle = [x for x in driver.window_handles if x != parent_handle][0]
driver.switch_to.window(child_handle)

print(driver.current_window_handle)
driver.close()
driver.switch_to.window(parent_handle)

print(driver.current_window_handle)
assert windows_handle == driver.current_window_handle, 'Заголовок отличается'

new_window_button_locator = (By.ID, 'windowButton')
new_window_button = driver.find_element(*new_window_button_locator)

new_window_message_button_locator = (By.ID, 'messageWindowButton')
new_window_message_button = driver.find_element(*new_window_message_button_locator)

if new_tub_button.is_enabled(): print(new_tub_button.text)
if new_window_button.is_enabled(): print(new_window_button.text)
if new_window_message_button.is_enabled(): print(new_window_message_button.text)